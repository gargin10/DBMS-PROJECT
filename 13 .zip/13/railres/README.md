Railway Booking app -
by
Abhishek Bansod (200022)
Anushka Panda (200174)
Gargi Naladkar (200371)
Sana (200599)
Shreya Kacholia (180735)

#Front end: HTML, CSS, JavaScript
#Back end: PHP, MySQL
#PHP: Hypertext Preprocessor (PHP) is a technology that allows software developers to create
#dynamically generated web pages, in HTML, XML, or other document types, as per client request. PHP is open source software.
#MySQL: MySql is a database, widely used for accessing querying, updating, and managing data in databases.
#Software Requirement(any one)
#XAMPP Server

Following are the steps to configure the setup:Install “xampp”
Extract the .zip file and add the folder inside “C:\xampp\htdocs”.
Start xampp (MySQL)
Open the MySQL admin and create a new database “ralidraft” and import “railres.sql” from the folder.
Please note that the database name should be same as it is in the firstimport.php file.
Run “http://www.localhost/railres/” and we are ready to use -
